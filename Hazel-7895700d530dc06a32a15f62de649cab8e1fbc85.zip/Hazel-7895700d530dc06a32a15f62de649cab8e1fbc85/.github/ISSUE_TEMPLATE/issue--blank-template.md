---
name: 'Issue: Blank template'
about: For issues that are not a bug report or feature request

---

Please consider using the Bug report or Feature request template. If it doesn't belong there, feel free to use this (empty) template. Make sure to provide enough details so it is clear for contributors to help you out. Premature or incomplete issues cannot be resolved due to lack of information or unclear descriptions.

Make sure your issue can be reproduced with the Hazel Engine and not by your own engine that you're creating alongside with Hazel. For issues with your own engine, we're happy to help you in [TheCherno Discord server](https://thecherno.com/discord). Thanks for your understanding.
